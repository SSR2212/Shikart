function goToCheckout() {
    document.querySelector('.products').style.display = 'none';
    document.querySelector('#checkout').classList.remove('hidden');
}

function rollDice() {
    const result = Math.floor(Math.random() * 6) + 1;
    if (result === 6) {
        alert("Congratulations! You rolled a 6. Your purchase is FREE!");
    } else {
        alert("You rolled a " + result + ". Better luck next time! Payment is non-refundable.");
    }
}